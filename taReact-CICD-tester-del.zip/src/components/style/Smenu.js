/* eslint-disable import/no-extraneous-dependencies */
import styled from 'styled-components';

const Smenus = styled.span`
    font-size: 1.5em;
    text-align: center;
    color: red !important;
`;
export default Smenus;
