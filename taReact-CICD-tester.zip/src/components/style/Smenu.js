/* eslint-disable import/no-extraneous-dependencies */
import styled from 'styled-components';

const Smenus = styled.span`
    font-size: 1em;
    text-align: center;
`;
export default Smenus;
